// Navigation Menu Toggle
const mobileMenu = document.getElementById('mobile-menu');
const navMenu = document.querySelector('.nav-menu');

if (mobileMenu && navMenu) {
    mobileMenu.addEventListener('click', () => {
        mobileMenu.classList.toggle('active');
        navMenu.classList.toggle('active');
    });
    
    // Close menu when clicking on links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            mobileMenu.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });
}

// Set active navigation link based on current page
function setActiveNavLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        
        // Get the page this link points to
        const linkPage = link.getAttribute('href');
        
        if (currentPage === linkPage || 
            (currentPage === '' && linkPage === 'index.html') ||
            (currentPage.includes('index') && linkPage === 'index.html')) {
            link.classList.add('active');
        }
    });
}

// Hero Slider
let currentSlide = 0;
let slideInterval;

function initSlider() {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    
    if (!slides.length) return;
    
    function goToSlide(n) {
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));
        
        currentSlide = (n + slides.length) % slides.length;
        
        slides[currentSlide].classList.add('active');
        dots[currentSlide].classList.add('active');
    }
    
    function nextSlide() {
        goToSlide(currentSlide + 1);
    }
    
    function prevSlide() {
        goToSlide(currentSlide - 1);
    }
    
    // Auto slide every 6 seconds
    slideInterval = setInterval(nextSlide, 6000);
    
    // Event listeners
    if (prevBtn) prevBtn.addEventListener('click', () => {
        clearInterval(slideInterval);
        prevSlide();
        slideInterval = setInterval(nextSlide, 6000);
    });
    
    if (nextBtn) nextBtn.addEventListener('click', () => {
        clearInterval(slideInterval);
        nextSlide();
        slideInterval = setInterval(nextSlide, 6000);
    });
    
    // Dot navigation
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            clearInterval(slideInterval);
            goToSlide(index);
            slideInterval = setInterval(nextSlide, 6000);
        });
    });
}

// Gallery Data - 20 Images with Categories
const galleryData = [
    {
        id: 1,
        src: 'images/gallery/01.jpg',
        alt: 'Commercial AC Installation',
        title: 'Commercial AC Installation',
        category: 'installation',
        description: 'Large-scale commercial HVAC installation for office building'
    },
    {
        id: 2,
        src: 'images/gallery/02.jpg',
        alt: 'AC Unit Repair',
        title: 'AC Unit Repair',
        category: 'repair',
        description: 'Diagnosing and repairing faulty compressor unit'
    },
    {
        id: 3,
        src: 'images/gallery/03.jpg',
        alt: 'Regular Maintenance',
        title: 'Regular Maintenance',
        category: 'maintenance',
        description: 'Preventive maintenance check and cleaning'
    },
    {
        id: 4,
        src: 'images/gallery/04.jpg',
        alt: 'Residential Installation',
        title: 'Residential Installation',
        category: 'installation',
        description: 'Split system installation in modern home'
    },
    {
        id: 5,
        src: 'images/gallery/05.jpg',
        alt: 'Office Building HVAC',
        title: 'Office Building HVAC',
        category: 'commercial',
        description: 'Complete office building climate control system'
    },
    {
        id: 6,
        src: 'images/gallery/06.jpg',
        alt: 'Home AC Setup',
        title: 'Home AC Setup',
        category: 'residential',
        description: 'Residential air conditioning system installation'
    },
    {
        id: 7,
        src: 'images/gallery/07.jpg',
        alt: 'Emergency Repair',
        title: 'Emergency Repair',
        category: 'repair',
        description: '24/7 emergency repair service'
    },
    {
        id: 8,
        src: 'images/gallery/08.jpg',
        alt: 'System Tune-up',
        title: 'System Tune-up',
        category: 'maintenance',
        description: 'Seasonal AC tune-up and optimization'
    },
    {
        id: 9,
        src: 'images/gallery/09.jpg',
        alt: 'Ductwork Installation',
        title: 'Ductwork Installation',
        category: 'installation',
        description: 'Professional ductwork setup for central system'
    },
    {
        id: 10,
        src: 'images/gallery/10.jpg',
        alt: 'Retail Store AC',
        title: 'Retail Store AC',
        category: 'commercial',
        description: 'Shopping center HVAC system installation'
    },
    {
        id: 11,
        src: 'images/gallery/11.jpg',
        alt: 'Apartment Cooling',
        title: 'Apartment Cooling',
        category: 'residential',
        description: 'Multi-unit residential cooling system'
    },
    {
        id: 12,
        src: 'images/gallery/12.jpg',
        alt: 'Component Replacement',
        title: 'Component Replacement',
        category: 'repair',
        description: 'Replacing damaged HVAC components'
    },
    {
        id: 13,
        src: 'images/gallery/13.jpg',
        alt: 'Filter Replacement',
        title: 'Filter Replacement',
        category: 'maintenance',
        description: 'Regular filter maintenance and replacement'
    },
    {
        id: 14,
        src: 'images/gallery/14.jpg',
        alt: 'New Construction',
        title: 'New Construction',
        category: 'installation',
        description: 'HVAC installation for new building construction'
    },
    {
        id: 15,
        src: 'images/gallery/15.jpg',
        alt: 'Warehouse Cooling',
        title: 'Warehouse Cooling',
        category: 'commercial',
        description: 'Industrial warehouse climate control system'
    },
    {
        id: 16,
        src: 'images/gallery/16.jpg',
        alt: 'Villa AC System',
        title: 'Villa AC System',
        category: 'residential',
        description: 'Luxury villa air conditioning installation'
    },
    {
        id: 17,
        src: 'images/gallery/17.jpg',
        alt: 'Electrical Repair',
        title: 'Electrical Repair',
        category: 'repair',
        description: 'Fixing electrical issues in HVAC system'
    },
    {
        id: 18,
        src: 'images/gallery/18.jpg',
        alt: 'Cleaning Service',
        title: 'Cleaning Service',
        category: 'maintenance',
        description: 'Deep cleaning of AC units and components'
    },
    {
        id: 19,
        src: 'images/gallery/19.jpg',
        alt: 'Multi-Split System',
        title: 'Multi-Split System',
        category: 'installation',
        description: 'Advanced multi-split system installation'
    },
    {
        id: 20,
        src: 'images/gallery/20.jpg',
        alt: 'Hotel HVAC',
        title: 'Hotel HVAC',
        category: 'commercial',
        description: 'Hotel climate control system installation'
    }
];

// For placeholder images if actual images don't exist
const placeholderImages = [
    'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=80',
    'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600&q=80',
    'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80',
    'https://images.unsplash.com/photo-1545128485-c400eaa79dca?w=600&q=80',
    'https://images.unsplash.com/photo-1581094792910-d5d34fdd7a28?w=600&q=80',
    'https://images.unsplash.com/photo-1581094792508-4d9532c48a7c?w=600&q=80',
    'https://images.unsplash.com/photo-1581094792596-8ded2d7c3d4c?w=600&q=80',
    'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600&q=80',
    'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=80',
    'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80',
    'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600&q=80',
    'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=80',
    'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80',
    'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600&q=80',
    'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=80',
    'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80',
    'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600&q=80',
    'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=600&q=80',
    'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80',
    'https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=600&q=80'
];

// Initialize Gallery
function initGallery() {
    const galleryContainer = document.getElementById('gallery-container');
    if (!galleryContainer) return;
    
    // Create gallery HTML
    let galleryHTML = '';
    
    galleryData.forEach((image, index) => {
        // Use placeholder if local image doesn't exist
        const imgSrc = placeholderImages[index % placeholderImages.length];
        
        galleryHTML += `
            <div class="gallery-item" data-id="${image.id}" data-category="${image.category}">
                <img src="${imgSrc}" alt="${image.alt}" 
                     data-actual-src="${image.src}" 
                     data-title="${image.title}" 
                     data-description="${image.description}"
                     onerror="this.src='${placeholderImages[index % placeholderImages.length]}'">
                <div class="gallery-overlay">
                    <h4>${image.title}</h4>
                    <p>${image.category.charAt(0).toUpperCase() + image.category.slice(1)}</p>
                </div>
            </div>
        `;
    });
    
    galleryContainer.innerHTML = galleryHTML;
    
    // Initialize gallery filtering
    initGalleryFilters();
    
    // Initialize lightbox
    initLightbox();
}

// Gallery Filtering
function initGalleryFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const galleryItems = document.querySelectorAll('.gallery-item');
    
    if (!filterButtons.length || !galleryItems.length) return;
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            // Add active class to clicked button
            button.classList.add('active');
            
            const filter = button.getAttribute('data-filter');
            
            // Filter gallery items
            galleryItems.forEach(item => {
                const category = item.getAttribute('data-category');
                
                if (filter === 'all' || category === filter) {
                    item.style.display = 'block';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'scale(1)';
                    }, 10);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
}

// Lightbox Functionality
let currentLightboxIndex = 0;
let lightboxImages = [];

function initLightbox() {
    const galleryItems = document.querySelectorAll('.gallery-item');
    const lightbox = document.getElementById('lightbox');
    const closeBtn = document.querySelector('.close-lightbox');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    
    if (!galleryItems.length || !lightbox) return;
    
    // Prepare lightbox images array
    galleryItems.forEach(item => {
        const img = item.querySelector('img');
        lightboxImages.push({
            src: img.getAttribute('data-actual-src') || img.src,
            title: img.getAttribute('data-title'),
            description: img.getAttribute('data-description'),
            alt: img.alt
        });
    });
    
    // Add click event to gallery items
    galleryItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            openLightbox(index);
        });
    });
    
    // Close lightbox
    if (closeBtn) {
        closeBtn.addEventListener('click', closeLightbox);
    }
    
    // Close when clicking outside image
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });
    
    // Navigation buttons
    if (prevBtn) {
        prevBtn.addEventListener('click', () => navigateLightbox(-1));
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => navigateLightbox(1));
    }
    
    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (lightbox.classList.contains('active')) {
            if (e.key === 'Escape') closeLightbox();
            if (e.key === 'ArrowLeft') navigateLightbox(-1);
            if (e.key === 'ArrowRight') navigateLightbox(1);
        }
    });
}

function openLightbox(index) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxTitle = document.getElementById('lightbox-title');
    const lightboxDesc = document.getElementById('lightbox-desc');
    const lightboxCounter = document.getElementById('lightbox-counter');
    
    if (index >= 0 && index < lightboxImages.length) {
        currentLightboxIndex = index;
        const image = lightboxImages[index];
        
        // Use placeholder if image fails to load
        const img = new Image();
        img.onload = () => {
            lightboxImg.src = image.src;
        };
        img.onerror = () => {
            lightboxImg.src = placeholderImages[index % placeholderImages.length];
        };
        img.src = image.src;
        
        lightboxTitle.textContent = image.title;
        lightboxDesc.textContent = image.description;
        lightboxCounter.textContent = `${index + 1} of ${lightboxImages.length}`;
        
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    lightbox.classList.remove('active');
    document.body.style.overflow = 'auto';
}

function navigateLightbox(direction) {
    currentLightboxIndex = (currentLightboxIndex + direction + lightboxImages.length) % lightboxImages.length;
    openLightbox(currentLightboxIndex);
}

// Contact Form
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    
    if (!contactForm) return;
    
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const name = document.getElementById('name').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const email = document.getElementById('email')?.value.trim() || '';
        const service = document.getElementById('service').value;
        const message = document.getElementById('message').value.trim();
        
        // Simple validation
        if (!name || !phone || !message) {
            alert('Please fill in all required fields (Name, Phone, Message).');
            return;
        }
        
        // In a real application, you would send this data to a server
        // For now, we'll show a success message
        
        // Show loading state
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        submitBtn.disabled = true;
        
        // Simulate API call
        setTimeout(() => {
            // Show success message
            alert(`Thank you, ${name}! Your message has been received.\n\nWe will contact you at ${phone} within 24 hours regarding your ${service || 'service'} request.`);
            
            // Reset form
            contactForm.reset();
            
            // Reset button
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
            
            // In a real application, you would redirect or show a success message on page
            // window.location.href = 'thank-you.html';
            
        }, 1500);
    });
}

// Smooth scrolling for anchor links
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Only process anchor links, not page links
            if (href === '#' || href.startsWith('#!')) {
                e.preventDefault();
                return;
            }
            
            if (href.startsWith('#')) {
                e.preventDefault();
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// Image loading optimization
function optimizeImageLoading() {
    const images = document.querySelectorAll('img[data-src], img[data-actual-src]');
    
    images.forEach(img => {
        const actualSrc = img.getAttribute('data-actual-src') || img.getAttribute('data-src');
        if (actualSrc) {
            // Load image in background
            const tempImg = new Image();
            tempImg.onload = () => {
                img.src = actualSrc;
                img.classList.add('loaded');
            };
            tempImg.src = actualSrc;
        }
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Set active navigation
    setActiveNavLink();
    
    // Initialize hero slider
    initSlider();
    
    // Initialize gallery if on gallery page
    if (document.querySelector('.gallery-grid') || document.getElementById('gallery-container')) {
        initGallery();
    }
    
    // Initialize contact form
    initContactForm();
    
    // Initialize smooth scrolling
    initSmoothScrolling();
    
    // Optimize image loading
    optimizeImageLoading();
    
    // Add loading animation to service cards
    const serviceCards = document.querySelectorAll('.service-card');
    serviceCards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
        
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });
    
    // Add current year to footer
    const yearSpan = document.getElementById('current-year');
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});

// Handle page visibility change for slider
document.addEventListener('visibilitychange', function() {
    if (slideInterval) {
        if (document.hidden) {
            clearInterval(slideInterval);
        } else {
            initSlider();
        }
    }
});

// Handle window resize
let resizeTimer;
window.addEventListener('resize', function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
        // Reinitialize anything that needs it on resize
        setActiveNavLink();
    }, 250);
});