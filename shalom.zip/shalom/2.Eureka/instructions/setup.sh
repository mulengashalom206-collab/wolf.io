#!/bin/bash

echo "==========================================="
echo "EUREKA TECH ZM WEBSITE SETUP"
echo "==========================================="
echo

echo "Creating folder structure..."
mkdir -p images/hero
mkdir -p images/gallery
mkdir -p css
mkdir -p js
mkdir -p INSTRUCTIONS

echo
echo "Folder structure created!"
echo
echo "NEXT STEPS:"
echo "1. Copy HTML files to main folder"
echo "2. Copy style.css to css/ folder"
echo "3. Copy script.js to js/ folder"
echo "4. Add images to images/ folder"
echo
echo "For images, run: download-images.sh"
echo